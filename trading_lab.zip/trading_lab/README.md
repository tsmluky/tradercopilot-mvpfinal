# Trading Lab

Este es el laboratorio de estrategias cuantitativas de **TradeCopilot**.

Aquí se testean setups técnicos, se generan insights para IA y se validan hipótesis de trading antes de integrarlas en la app principal.
